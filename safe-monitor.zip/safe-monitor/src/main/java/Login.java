import entidades.Usuario;

public class Login {

    private Query queryBD;

    private Usuario usuarioLogado;

    public Login() {
        this.queryBD = new Query();
    }

    public Boolean procurarUsuario(String email, String senha){

        Boolean usuarioEncontrado = false;

        queryBD.buscarUsuariosBanco();

        for (int i = 0; i < queryBD.getUsuarios().size(); i++) {

            if(email.equals(queryBD.getUsuarios().get(i).getEmail()) &&
                    senha.equals(queryBD.getUsuarios().get(i).getSenha())){

                usuarioLogado = queryBD.getUsuarios().get(i);
                usuarioEncontrado = true;
            }
        }
        return usuarioEncontrado;
    }

    public String login(String email, String senha){

        String mensagem = "";

        if (procurarUsuario(email,senha)){
            mensagem = "Parábens! Você logou!";
        }else {
            mensagem = "Email ou senha inválidos!";
        }

        return mensagem;
    }

    public Boolean  verificarPermissoesUsuario(){

        Boolean usuarioAdmin = true;

        queryBD.buscarUsuariosBanco();

        if(usuarioLogado.getCadastrar() == 0 &&
           usuarioLogado.getDeletar() ==0 &&
           usuarioLogado.getAlterar() == 0){
                usuarioAdmin = false;

        }
        return usuarioAdmin;
    }

    public Usuario getUsuarioLogado() {
        return usuarioLogado;
    }

    public void setUsuarioLogado(Usuario usuarioLogado) {
        this.usuarioLogado = usuarioLogado;
    }
}
